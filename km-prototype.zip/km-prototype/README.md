# Integrated KM Prototype

A working, single-file demo of the **Integrated KM Process Map** proposed in
*"A Comparative Study of Knowledge Management Practices in Google, Microsoft and Infosys"*
(Assignment 02, Unit II — Knowledge Management).

**Team:** Rithish K · Siva Bharathi M · Nithin S

## What it demonstrates

| Tab | Unit II Concept | Inspired by |
|---|---|---|
| 📦 Repository | KM Version I — Knowledge as Possession | Infosys KShop |
| 💬 Communities | KM Version II — Knowing Through Participation | Google open forums; Open vs. Clique knowledge markets |
| 🏆 Knowledge Market | Reciprocity, reputation, and currency-based incentives | Infosys Knowledge Currency Units (KCUs) |
| 🧠 Tacit Capture | Polanyi/Ryle's tacit knowledge ("knowing how") | Sun Microsystems & Maryland reference-effectiveness examples |

It is a **static, client-side app** — plain HTML/CSS/JavaScript, no build step,
no server, no database. All data lives in memory and resets on page reload
(by design, for a lightweight academic demo — see "Next steps" below to make
it persistent).

## Run it locally

Just open `index.html` in any browser. That's it — no install, no dependencies.

## Publish it to GitHub (with a live link)

Run these commands from inside this folder (replace `YOUR-USERNAME` and
`REPO-NAME` with your own):

```bash
git init
git add .
git commit -m "Initial commit: Integrated KM prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/REPO-NAME.git
git push -u origin main
```

Then turn on **GitHub Pages** so you get a shareable live link:

1. Go to your repo on GitHub → **Settings** → **Pages**
2. Under "Build and deployment", set **Source** to `Deploy from a branch`
3. Set **Branch** to `main` and folder to `/ (root)` → **Save**
4. After a minute, your live link will appear at:
   `https://YOUR-USERNAME.github.io/REPO-NAME/`

Use that link in your presentation/demo, and paste it into your report's
"Proposed Solution" section as the working prototype reference.

## Next steps (optional, for extra credit / deeper implementation)

- Swap the in-memory `artifacts`/`threads`/`tacitLogs` arrays for calls to a
  real backend (e.g., Firebase, Supabase, or a small Node/Express + SQLite
  API) so contributions persist across sessions.
- Add authentication so KCU points map to real user accounts.
- Add a search/filter bar on the Repository tab (tag + keyword).
- Export the leaderboard and repository as CSV for the report's "Comparative
  Analysis" appendix.

## File structure

```
km-prototype/
├── index.html    # the entire app (HTML + CSS + JS, single file)
└── README.md      # this file
```
